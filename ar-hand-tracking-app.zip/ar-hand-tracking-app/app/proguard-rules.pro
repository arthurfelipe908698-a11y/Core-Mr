# This is a configuration file for ProGuard.
# http://proguard.sourceforge.net/index.html#manual/usage.html

-dontusemixedcaseclassnames
# Keep line numbers for stack traces
-keepattributes SourceFile,LineNumberTable
# Hide the original source file name.
-renamesourcefileattribute SourceFile

# Keep Android framework classes
-keep public class android.** { *; }

# Keep androidx classes
-keep public class androidx.** { *; }

# Keep application classes
-keep public class com.example.arhandtracking.** { *; }

# Keep MediaPipe classes
-keep class com.google.mediapipe.** { *; }
-keepclassmembers class com.google.mediapipe.** { *; }

# Keep ARCore classes
-keep class com.google.ar.** { *; }
-keepclassmembers class com.google.ar.** { *; }

# Preserve the line numbers of all the classes in camera package
-keepattributes SourceFile,LineNumberTable
-keep public class androidx.camera.** {*;}
