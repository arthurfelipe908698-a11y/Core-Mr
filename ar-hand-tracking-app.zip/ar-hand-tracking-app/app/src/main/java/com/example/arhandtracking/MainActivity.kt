package com.example.arhandtracking

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.arhandtracking.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupUI()
    }

    private fun setupUI() {
        binding.btnStartAR.setOnClickListener {
            startARActivity()
        }
        
        binding.btnSettings.setOnClickListener {
            showSettings()
        }
        
        binding.btnAbout.setOnClickListener {
            showAbout()
        }
    }

    private fun startARActivity() {
        val intent = Intent(this, ARActivity::class.java)
        startActivity(intent)
    }

    private fun showSettings() {
        binding.tvInfo.text = "⚙️ Configurações\n\n" +
                "• Sensibilidade: Média\n" +
                "• Modo: Hand Tracking + AR\n" +
                "• Resolução: 1080p\n" +
                "• FPS: 30"
    }

    private fun showAbout() {
        binding.tvInfo.text = "ℹ️ Sobre o App\n\n" +
                "AR Hand Tracking App v1.0.0\n\n" +
                "Aplicação de realidade aumentada com detecção de mãos.\n\n" +
                "Tecnologias:\n" +
                "• Google ARCore\n" +
                "• MediaPipe Hand Tracking\n" +
                "• Android Camera2 API"
    }
}
