package com.example.arhandtracking

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

class HandTrackingView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var landmarks: List<Pair<Float, Float>> = emptyList()
    
    private val paintPoint = Paint().apply {
        color = Color.GREEN
        style = Paint.Style.FILL
        isAntiAlias = true
    }
    
    private val paintLine = Paint().apply {
        color = Color.YELLOW
        style = Paint.Style.STROKE
        strokeWidth = 4f
        isAntiAlias = true
    }
    
    private val paintText = Paint().apply {
        color = Color.WHITE
        textSize = 24f
        isAntiAlias = true
    }

    // Conexões entre pontos (esqueleto da mão)
    private val fingerConnections = listOf(
        // Pulso para dedos
        0 to 1, 0 to 5, 0 to 9, 0 to 13, 0 to 17,
        // Polegar
        1 to 2, 2 to 3, 3 to 4,
        // Índice
        5 to 6, 6 to 7, 7 to 8,
        // Meio
        9 to 10, 10 to 11, 11 to 12,
        // Anel
        13 to 14, 14 to 15, 15 to 16,
        // Mindinho
        17 to 18, 18 to 19, 19 to 20
    )

    fun updateLandmarks(newLandmarks: List<Pair<Float, Float>>) {
        landmarks = newLandmarks
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        
        if (landmarks.isEmpty()) {
            canvas.drawText("Aguardando detecção de mão...", 50f, 100f, paintText)
            return
        }

        // Desenhar conexões (ossos)
        for ((from, to) in fingerConnections) {
            if (from < landmarks.size && to < landmarks.size) {
                val (x1, y1) = landmarks[from]
                val (x2, y2) = landmarks[to]
                
                canvas.drawLine(
                    x1 * width,
                    y1 * height,
                    x2 * width,
                    y2 * height,
                    paintLine
                )
            }
        }

        // Desenhar pontos (juntas)
        for ((x, y) in landmarks) {
            val px = x * width
            val py = y * height
            canvas.drawCircle(px, py, 8f, paintPoint)
        }
        
        // Desenhar informações
        canvas.drawText("Landmarks detectados: ${landmarks.size}", 20f, 50f, paintText)
    }
}
