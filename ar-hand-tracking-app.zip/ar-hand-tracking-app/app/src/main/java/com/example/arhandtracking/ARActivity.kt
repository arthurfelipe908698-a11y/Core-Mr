package com.example.arhandtracking

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.arhandtracking.databinding.ActivityArBinding
import com.google.ar.core.ArCoreApk
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class ARActivity : AppCompatActivity() {

    private lateinit var binding: ActivityArBinding
    private lateinit var cameraExecutor: ExecutorService
    private var arCoreInstalled = false

    companion object {
        private const val CAMERA_PERMISSION_REQUEST_CODE = 100
        private const val TAG = "ARActivity"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        binding = ActivityArBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        cameraExecutor = Executors.newSingleThreadExecutor()
        
        // Verificar instalação do ARCore
        checkARCoreInstalled()
        
        // Verificar permissão de câmera
        if (allPermissionsGranted()) {
            startCamera()
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CAMERA),
                CAMERA_PERMISSION_REQUEST_CODE
            )
        }
        
        setupUI()
    }

    private fun checkARCoreInstalled() {
        when (ArCoreApk.getInstance().requestInstall(this, true)) {
            ArCoreApk.InstallStatus.INSTALLED -> {
                arCoreInstalled = true
                binding.tvStatus.text = "✓ ARCore Pronto"
            }
            ArCoreApk.InstallStatus.INSTALL_REQUESTED -> {
                arCoreInstalled = false
                binding.tvStatus.text = "Instalando ARCore..."
            }
        }
    }

    private fun allPermissionsGranted() =
        ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            
            val preview = androidx.camera.core.Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(binding.previewView.surfaceProvider)
                }
            
            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor, HandTrackingAnalyzer { landmarks ->
                        updateHandLandmarks(landmarks)
                    })
                }
            
            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
            
            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview, imageAnalyzer
                )
            } catch (exc: Exception) {
                Toast.makeText(this, "Erro ao iniciar câmera: ${exc.message}", Toast.LENGTH_SHORT).show()
            }
            
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setupUI() {
        binding.btnCapture.setOnClickListener {
            captureSnapshot()
        }
        
        binding.btnToggleTracking.setOnClickListener {
            toggleTracking()
        }
        
        binding.btnBack.setOnClickListener {
            finish()
        }
    }

    private fun updateHandLandmarks(landmarks: List<Pair<Float, Float>>) {
        binding.handTrackingView.updateLandmarks(landmarks)
    }

    private fun captureSnapshot() {
        Toast.makeText(this, "Captura salva!", Toast.LENGTH_SHORT).show()
    }

    private fun toggleTracking() {
        val isEnabled = binding.toggleTracking.isChecked
        binding.tvInfo.text = if (isEnabled) {
            "Hand Tracking: ATIVADO ✓"
        } else {
            "Hand Tracking: DESATIVADO ✗"
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (allPermissionsGranted()) {
                startCamera()
            } else {
                Toast.makeText(this, "Permissão de câmera negada", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}
