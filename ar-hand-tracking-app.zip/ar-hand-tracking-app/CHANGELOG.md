# Changelog

Todas as mudanças significativas neste projeto serão documentadas neste arquivo.

O formato é baseado em [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
e este projeto segue [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2024-01-15

### Added
- Realidade aumentada com Google ARCore
- Detecção de mão com MediaPipe
- Interface principal com opções de menu
- Atividade AR com preview em tempo real
- Visualização de landmarks da mão
- Toggle para ativar/desativar tracking
- Captura de snapshots
- Workflows GitHub Actions para build automático
- Suporte a Android 7.0+
- Documentação completa

### Changed
- Estrutura inicial do projeto

### Fixed
- Nada ainda

### Removed
- N/A

## [0.1.0] - 2024-01-01

### Added
- Setup inicial do projeto
- Estrutura base do Android
- Configuração de build.gradle
- README inicial

---

## Notas de Versão Futuras

### Planejado para v1.1.0
- [ ] Gravação de vídeo em AR
- [ ] Filtros e efeitos visuais
- [ ] Persistência de configurações
- [ ] Histórico de capturas
- [ ] Modo retrato e paisagem

### Planejado para v1.2.0
- [ ] Suporte a reconhecimento de gestos
- [ ] Integração com Google Drive
- [ ] Tema escuro/claro
- [ ] Múltiplos idiomas
- [ ] Analytics

### Ideias para Futuro
- Exportar dados de tracking
- Modo multiplayer
- Efeitos de partículas
- Machine Learning customizado
- Suporte a WebGL

---

## Processo de Lançamento

1. Atualizar CHANGELOG
2. Bump versão em build.gradle
3. Criar tag git: `git tag -a v1.0.0 -m "Release v1.0.0"`
4. Push: `git push origin v1.0.0`
5. GitHub Actions gera APK automaticamente
6. Criar Release no GitHub com APK

## Como Contribuir

Veja CONTRIBUTING.md para instruções.
