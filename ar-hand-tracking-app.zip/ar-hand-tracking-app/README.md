# AR Hand Tracking App

Aplicação Android de realidade aumentada com detecção de rastreamento de mão em tempo real usando Google ARCore e MediaPipe.

## 🎯 Características

- ✨ Realidade aumentada com Google ARCore
- 👋 Detecção e rastreamento de mão com MediaPipe
- 📱 Interface intuitiva
- 🎨 Visualização em tempo real dos landmarks da mão
- 📸 Captura de snapshots
- ⚙️ Configurações personalizáveis
- 🤖 Hand Tracking com 21 pontos de referência

## 📋 Requisitos

- Android 7.0 (API 24) ou superior
- Dispositivo com câmera frontal
- Suporte a ARCore (verificar compatibilidade)
- Espaço de armazenamento: ~200MB

### Dependências

- Android Studio 2021.1 ou superior
- JDK 11
- Gradle 7.4+

## 🚀 Instalação

### Via APK

1. Faça download do arquivo APK na seção de Releases
2. Instale em seu dispositivo Android
3. Conceda as permissões necessárias (câmera)

### Build Local

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/ARHandTrackingApp.git
cd ARHandTrackingApp
```

2. Abra no Android Studio ou compile via linha de comando:
```bash
./gradlew build
```

3. Para gerar o APK:
```bash
# Debug
./gradlew assembleDebug

# Release
./gradlew assembleRelease
```

4. O APK estará em `app/build/outputs/apk/`

## 📝 Uso

1. Abra o aplicativo
2. Toque em "Iniciar AR"
3. Aponte a câmera frontal para sua mão
4. O app detectará automaticamente os pontos de referência
5. Use os controles na parte inferior para:
   - Ativar/desativar tracking
   - Capturar snapshots
   - Voltar à tela inicial

## 🏗️ Estrutura do Projeto

```
ARHandTrackingApp/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/example/arhandtracking/
│   │       │   ├── MainActivity.kt
│   │       │   ├── ARActivity.kt
│   │       │   ├── HandTrackingAnalyzer.kt
│   │       │   └── HandTrackingView.kt
│   │       └── res/
│   │           ├── layout/
│   │           ├── values/
│   │           └── xml/
│   └── build.gradle
├── .github/
│   └── workflows/
│       ├── build-apk.yml
│       └── test.yml
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## 🔧 Configuração

### Assinatura de Release (GitHub Actions)

Para configurar build automático de APK assinado:

1. Gere uma chave de assinatura:
```bash
keytool -genkey -v -keystore release.keystore \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias android-release
```

2. Codifique em base64:
```bash
base64 -i release.keystore | xclip -selection clipboard
```

3. Adicione os secrets no GitHub:
   - `SIGNING_KEY`: Keystore em base64
   - `SIGNING_KEY_ALIAS`: alias da chave
   - `SIGNING_KEY_STORE_PASSWORD`: senha do keystore
   - `SIGNING_KEY_PASSWORD`: senha da chave

## 🤖 Tecnologias Utilizadas

- **Android SDK**: Development framework
- **Kotlin**: Linguagem de programação
- **Google ARCore**: Realidade aumentada
- **MediaPipe**: Detecção de mão
- **AndroidX Camera**: Acesso à câmera
- **Gradle**: Build automation

## 📊 Fluxo de Detecção

1. **Captura**: Câmera frontal captura frame em tempo real
2. **Análise**: MediaPipe Hand Landmarker detecta 21 pontos da mão
3. **Normalização**: Coordenadas normalizadas (0-1)
4. **Renderização**: Pontos e conexões desenhadas na tela
5. **Feedback**: Informações de status exibidas ao usuário

## 🎓 Recursos de Aprendizado

- [Google ARCore Documentation](https://developers.google.com/ar)
- [MediaPipe Hands](https://google.github.io/mediapipe/solutions/hands)
- [Android Camera2 API](https://developer.android.com/reference/android/hardware/camera2)
- [Kotlin Documentation](https://kotlinlang.org/docs/)

## 🐛 Troubleshooting

### App fecha após abrir
- Verifique se ARCore está instalado
- Conceda permissão de câmera
- Reinicie o dispositivo

### Hand tracking não funciona
- Certifique-se que a câmera está desobstruída
- Teste com melhor iluminação
- Verifique compatibilidade do dispositivo

### Build falha
- Execute `./gradlew clean`
- Atualize as dependências
- Verifique versão do Java: `java -version`

## 📱 Compatibilidade

- ✅ Android 7.0+ (API 24+)
- ✅ Android 8.0 Oreo
- ✅ Android 9 Pie
- ✅ Android 10
- ✅ Android 11
- ✅ Android 12
- ✅ Android 13

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.

## 🤝 Contribuições

Contribuições são bem-vindas! Para contribuir:

1. Fork o repositório
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## ⚠️ Aviso Legal

Este aplicativo coleta dados de câmera em tempo real. Certifique-se de informar os usuários sobre privacidade e dados.

## 📞 Suporte

Para reportar bugs ou sugerir features, abra uma issue no GitHub.

## 🙏 Agradecimentos

- Google pela plataforma ARCore
- Google Research pelo MediaPipe
- Comunidade Android

---

**Desenvolvido com ❤️ para realidade aumentada**
