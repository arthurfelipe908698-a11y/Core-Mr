# Guia de Instalação - AR Hand Tracking App

## 📱 Instalação via APK

### Método 1: Download Direto

1. **Baixe o APK:**
   - Vá para [Releases](https://github.com/seu-usuario/ARHandTrackingApp/releases)
   - Download o arquivo `app-release.apk` ou `app-debug.apk`

2. **Transfira para o Dispositivo:**
   - USB: Conecte via cabo USB em modo de transferência
   - Drive em Nuvem: Upload no Google Drive/OneDrive
   - Email: Envie para você mesmo

3. **Instale o APK:**
   - Abra o gerenciador de arquivos
   - Navegue até o arquivo APK
   - Toque em instalar
   - Conceda permissões quando solicitado

### Método 2: Build Local com Android Studio

1. **Configure o Ambiente:**
   - Instale [Android Studio](https://developer.android.com/studio)
   - Instale SDK Android 33
   - Configure emulador ou dispositivo

2. **Clone o Repositório:**
   ```bash
   git clone https://github.com/seu-usuario/ARHandTrackingApp.git
   cd ARHandTrackingApp
   ```

3. **Abra no Android Studio:**
   - File → Open
   - Selecione a pasta do projeto
   - Aguarde indexação

4. **Execute:**
   - Build → Make Project
   - Run → Run 'app'
   - Selecione dispositivo/emulador

### Método 3: Build via Linha de Comando

1. **Pré-requisitos:**
   ```bash
   # Verifique Java
   java -version  # Deve ser 11+
   
   # Verifique Android SDK
   echo $ANDROID_HOME
   ```

2. **Clone e Compile:**
   ```bash
   git clone https://github.com/seu-usuario/ARHandTrackingApp.git
   cd ARHandTrackingApp
   chmod +x gradlew
   ./gradlew assembleDebug
   ```

3. **Instale no Dispositivo:**
   ```bash
   # Conecte via USB com modo debug ativado
   ./gradlew installDebug
   
   # Ou transfira o APK
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

## ✅ Pré-requisitos do Sistema

### Hardware

- **Processador:** ARM64 ou superior
- **RAM:** Mínimo 2GB (recomendado 4GB)
- **Armazenamento:** 200MB livres
- **Câmera:** Câmera frontal/traseira

### Software

- **Android:** Versão 7.0 (API 24) ou superior
- **ARCore:** Google Play Services com AR
- **Permissões:** Câmera e armazenamento

## 📋 Verificar Compatibilidade

### ARCore Compatibility

1. **Método Online:**
   - Visite [Suported Devices](https://support.google.com/arcore/answer/9038075)
   - Procure seu modelo de dispositivo

2. **Método Local:**
   ```bash
   # Instale o app de teste ARCore
   adb install arcore-sample.apk
   # Se funcionar, seu dispositivo suporta
   ```

### Requisitos de Câmera

O app requer câmera frontal ou traseira com:
- Resolução mínima: 640x480
- Frame rate: 30 FPS
- Suporte a autofoco (recomendado)

## 🔧 Instalação de Dependências

### ARCore

ARCore é instalado automaticamente via Play Services. Se não tiver:

```bash
# Via Play Store
1. Abra Google Play Store
2. Procure "Google Play Services for AR"
3. Instale/Atualize

# Ou via APK (advanced)
adb install com.google.android.gms.apk
```

### Permissões Necessárias

O app solicita automaticamente:
- ✓ Acesso à câmera
- ✓ Acesso ao armazenamento
- ✓ Internet (para mediapipe models)

## 🚀 Primeiro Uso

1. **Abra o Aplicativo:**
   - Toque no ícone "AR Hand Tracking" na tela inicial

2. **Tela Principal:**
   - Conceda permissão de câmera
   - Toque em "Iniciar AR"

3. **Interface AR:**
   - Ajuste a câmera para sua mão
   - Hand tracking começará automaticamente
   - Veja os pontos de detecção em tempo real

4. **Controles:**
   - **Tracking Toggle:** Ativa/desativa detecção
   - **Capturar:** Salva screenshot
   - **Voltar:** Retorna ao menu principal

## 🐛 Problemas Comuns

### "Permissão de câmera negada"

**Solução:**
```bash
# Settings → Apps → AR Hand Tracking → Permissions
# Ativar "Camera" e "Storage"

# Via CLI:
adb shell pm grant com.example.arhandtracking android.permission.CAMERA
```

### "ARCore não disponível"

**Solução:**
1. Atualize Google Play Services
2. Reinicie o dispositivo
3. Verifique se dispositivo é compatível

### "Câmera não funciona"

**Diagnóstico:**
```bash
# Verifique dispositivos câmera
adb shell getprop ro.hardware.camera

# Teste câmera
adb shell am start -n com.android.camera/com.android.camera.Camera
```

### "Aplicativo congelado/lento"

**Soluções:**
- Feche outros apps
- Reduza resolução no menu settings
- Reinicie o dispositivo
- Limpe cache: Settings → Apps → Clear Cache

### "Erro ao instalar: 'Parse error'"

**Solução:**
- Baixe APK novamente (arquivo corrompido)
- Ative "Fontes desconhecidas" nas configurações
- Tente em outro dispositivo
- Verifique espaço disponível

## 📊 Verificar Instalação

```bash
# Listar pacotes instalados
adb shell pm list packages | grep arhandtracking

# Obter versão
adb shell dumpsys package com.example.arhandtracking | grep versionName

# Verificar permissões
adb shell pm list permissions granted | grep camera
```

## 🔄 Atualizar Aplicativo

### Via Play Store (quando disponível)
- Atualizações automáticas ativadas

### Via GitHub Releases
1. Baixe nova versão
2. Desinstale versão anterior
3. Instale novo APK

### Via Command Line
```bash
# Desinstalar
adb uninstall com.example.arhandtracking

# Instalar novo
adb install app-release-v1.1.0.apk
```

## 🗑️ Desinstalação

### Via Settings
1. Settings → Apps → AR Hand Tracking
2. Toque em "Desinstalar"
3. Confirme

### Via Command Line
```bash
adb uninstall com.example.arhandtracking
```

## 📞 Suporte

Se enfrentar problemas:

1. **Consulte a documentação:** [README.md](../README.md)
2. **Verifique issues existentes:** [GitHub Issues](https://github.com/seu-usuario/ARHandTrackingApp/issues)
3. **Abra uma nova issue:** Inclua logs e detalhes do dispositivo
4. **Envie feedback:** Sugestões de melhorias são bem-vindas

## 📝 Logs

Para reportar bugs, capture os logs:

```bash
# Limpar logs antigos
adb logcat -c

# Executar app e capturar logs
adb logcat > app_logs.txt

# Filtrar logs específicos
adb logcat *:S com.example.arhandtracking:V
```

## ✨ Próximos Passos

Após instalação com sucesso:

1. Explore as configurações
2. Teste com diferentes iluminações
3. Tente diferentes poses de mão
4. Capture alguns snapshots
5. Compartilhe seu feedback

**Divirta-se com Realidade Aumentada! 🎉**
