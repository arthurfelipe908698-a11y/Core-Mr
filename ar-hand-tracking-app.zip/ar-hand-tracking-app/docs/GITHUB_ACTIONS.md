# GitHub Actions - Build Automático de APK

Este documento explica como configurar e usar GitHub Actions para build automático de APK.

## 📋 Pré-requisitos

- Repositório GitHub
- Conta no GitHub
- Arquivo de workflow em `.github/workflows/`

## 🔑 Configuração de Secrets

### 1. Gerar Keystore de Assinatura

```bash
# Gerar chave de assinatura
keytool -genkey -v -keystore release.keystore \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000 \
  -alias android-release \
  -keypass sua-senha-chave \
  -storepass sua-senha-keystore
```

### 2. Codificar Keystore em Base64

```bash
# Linux/Mac
base64 -i release.keystore

# Windows PowerShell
[Convert]::ToBase64String([IO.File]::ReadAllBytes('release.keystore'))
```

### 3. Adicionar Secrets no GitHub

Vá para: Settings → Secrets and variables → Actions

Adicione os seguintes secrets:

| Nome | Valor |
|------|-------|
| `SIGNING_KEY` | Conteúdo base64 do keystore |
| `SIGNING_KEY_ALIAS` | `android-release` |
| `SIGNING_KEY_STORE_PASSWORD` | Sua senha do keystore |
| `SIGNING_KEY_PASSWORD` | Sua senha da chave |

## 📦 Workflows Disponíveis

### build-apk.yml

Dispara automaticamente quando:
- Push em `main` ou `develop`
- Criação de tag `v*`
- Pull request em `main`
- Disparo manual (workflow_dispatch)

**Produtos:**
- APK Debug
- APK Release (assinado)
- GitHub Release com arquivo (para tags)

### test.yml

Dispara em:
- Push em `main` ou `develop`
- Pull request em `main`

**Produtos:**
- Resultados de testes
- Relatórios de lint

## 🚀 Usar Build Automático

### Opção 1: Push para Branch

```bash
git push origin main
# GitHub Actions iniciará automaticamente
```

### Opção 2: Criar Tag de Release

```bash
# Crie uma tag de versão
git tag -a v1.0.0 -m "Release versão 1.0.0"
git push origin v1.0.0

# GitHub Actions fará build e criará Release automaticamente
```

### Opção 3: Disparar Manualmente

1. Vá para GitHub Actions
2. Selecione "Build APK"
3. Clique "Run workflow"

## 📥 Baixar APKs

### De Artifacts (Todos os builds)

1. Vá para GitHub Actions
2. Selecione o workflow executado
3. Desça até "Artifacts"
4. Download de `app-debug` ou `app-release`

### De GitHub Release (Apenas tags)

1. Vá para Releases
2. Encontre a versão desejada
3. Download do APK assinado

## 🐛 Troubleshooting

### Build falha com erro de permissão

```bash
chmod +x gradlew
git add gradlew
git commit -m "Fix: tornar gradlew executável"
git push
```

### Erro "JDK not found"

A ação `actions/setup-java@v3` já configura Java 11. Se ainda falhar:

```yaml
- name: Set up JDK
  uses: actions/setup-java@v3
  with:
    java-version: '11'
    distribution: 'temurin'
```

### Erro de assinatura

Verifique:
- ✅ Secrets estão configurados corretamente
- ✅ Alias da chave está correto
- ✅ Keystore é válido

```bash
# Validar keystore localmente
keytool -list -v -keystore release.keystore
```

### Build muito lento

GitHub Actions tem recursos limitados. Para acelerar:
- Use cache do Gradle (já configurado)
- Reduza dependências desnecessárias
- Use `assembleDebug` durante desenvolvimento

## 📊 Monitoramento

### Ver Status dos Workflows

1. Vá para GitHub Actions
2. Veja status dos últimos builds
3. Clique para detalhes completos

### Receber Notificações

GitHub notifica por padrão sobre falhas. Para configurar:
1. Settings → Notifications
2. Actions: "Notify on workflow failures"

## 🔒 Boas Práticas de Segurança

1. **Nunca commit keystore:**
   ```bash
   echo "release.keystore" >> .gitignore
   git add .gitignore
   ```

2. **Proteja secrets:**
   - Não compartilhe valores de secrets
   - Regenere se comprometido
   - Use diferentes secrets por ambiente

3. **Limite permissões de workflow:**
   ```yaml
   permissions:
     contents: read
   ```

4. **Auditore acessos:**
   - Verifique history de secrets
   - Revise quem tem acesso

## 📖 Referências

- [GitHub Actions Documentation](https://docs.github.com/actions)
- [Android Build Documentation](https://developer.android.com/build)
- [Gradle Documentation](https://docs.gradle.org/)
- [Signing Android Apps](https://developer.android.com/studio/publish/app-signing)

## 💡 Dicas e Truques

### Ignorar Build para Certos Commits

```bash
git commit -m "docs: atualizar README [skip ci]"
```

### Build Só para PR (não para push)

```yaml
on:
  pull_request:
    branches: [main]
  # Remover 'push'
```

### Usar Diferentes Estratégias por Branch

```yaml
on:
  push:
    branches:
      - main      # Build Release
      - develop   # Build Debug
```

## 📝 Exemplo Completo de Workflow

```yaml
name: Complete Build

on:
  push:
    branches: [main]
    tags: ['v*']

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup JDK
        uses: actions/setup-java@v3
        with:
          java-version: '11'
          distribution: 'temurin'
          cache: gradle
      
      - name: Build APK
        run: ./gradlew assembleRelease
      
      - name: Upload Artifact
        uses: actions/upload-artifact@v3
        with:
          name: app-release
          path: app/build/outputs/apk/release/
      
      - name: Create Release
        if: startsWith(github.ref, 'refs/tags/')
        uses: softprops/action-gh-release@v1
        with:
          files: app/build/outputs/apk/release/*.apk
```

---

**Para mais ajuda, consulte a documentação oficial ou abra uma issue.**
