# Contribuindo para AR Hand Tracking App

Obrigado por considerar contribuir para este projeto! Aqui estão algumas diretrizes para tornar o processo mais fácil.

## Como Contribuir

### Relatando Bugs

- Verifique se o bug já foi reportado na seção de Issues
- Se não, crie um novo issue com:
  - Título claro e descritivo
  - Descrição detalhada do comportamento
  - Passos para reproduzir
  - Comportamento esperado vs observado
  - Screenshots/vídeos se aplicável
  - Versão do Android e modelo do dispositivo

### Sugerindo Features

- Verifique se a sugestão já existe nas Issues
- Crie um novo issue com:
  - Descrição clara da feature
  - Motivação e casos de uso
  - Exemplos de como deveria funcionar

### Pull Requests

1. Fork o repositório
2. Crie uma branch (`git checkout -b feature/sua-feature`)
3. Siga o código existente e convenções de estilo
4. Faça commits claros e atômicos
5. Push para sua branch
6. Abra um Pull Request com descrição clara

## Padrões de Código

### Kotlin Style Guide

- Siga o [Kotlin Coding Conventions](https://kotlinlang.org/docs/coding-conventions.html)
- Use 4 espaços de indentação
- Nomes descritivos para variáveis
- Comentários para lógica complexa

### Estrutura de Classes

```kotlin
class MeuHelper {
    companion object {
        private const val TAG = "MeuHelper"
    }
    
    private val meuAtributo: String = ""
    
    fun minhaFuncao() {
        // implementação
    }
}
```

### Nomenclatura

- Classes: `PascalCase`
- Funções/variáveis: `camelCase`
- Constantes: `UPPER_SNAKE_CASE`
- Privadas: prefixo `_` (opcional)

## Fluxo de Desenvolvimento

```bash
# 1. Clone e configure
git clone https://github.com/seu-usuario/ARHandTrackingApp.git
cd ARHandTrackingApp

# 2. Crie sua branch
git checkout -b feature/sua-feature

# 3. Faça as mudanças
# ... editar arquivos ...

# 4. Teste
./gradlew test

# 5. Commit
git commit -m "feat: descrição clara da mudança"

# 6. Push
git push origin feature/sua-feature

# 7. Crie Pull Request no GitHub
```

## Mensagens de Commit

Use o padrão conventional commits:

- `feat:` Nova feature
- `fix:` Correção de bug
- `docs:` Mudanças em documentação
- `style:` Formatação/estilo
- `refactor:` Refatoração de código
- `test:` Testes
- `chore:` Tarefas de build/ci

Exemplo:
```
feat: adicionar suporte a gesto de pinça
fix: corrigir crash ao rotar câmera
docs: atualizar README com exemplos
```

## Testes

- Adicione testes unitários para novas features
- Teste em múltiplos dispositivos/versões do Android
- Execute `./gradlew test` antes de fazer commit

## Documentação

- Mantenha README.md atualizado
- Adicione comentários Javadoc/KDoc em funções públicas
- Documente mudanças significativas

## Processo de Review

1. Seu PR será revisado por maintainers
2. Pode haver pedidos de mudanças
3. Uma vez aprovado, será merged
4. Você será creditado no changelog

## Código de Conduta

- Seja respeitoso
- Aceite críticas construtivas
- Foco em o que é bom para a comunidade
- Sem spam ou conteúdo inadequado

## Perguntas?

Abra uma discussão ou entre em contato com os maintainers.

Obrigado por contribuir! 🎉
