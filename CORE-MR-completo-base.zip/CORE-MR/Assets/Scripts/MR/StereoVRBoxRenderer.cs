using UnityEngine;

namespace CoreMR.MR
{
    // Configuração simples de câmera estéreo para VR Box.
    // O efeito de barrel distortion deve ser aplicado por shader/material
    // no compositor final, calibrado para as lentes do aparelho.
    public sealed class StereoVRBoxRenderer : MonoBehaviour
    {
        [SerializeField] private Camera leftEye;
        [SerializeField] private Camera rightEye;
        [SerializeField, Range(0.055f, 0.075f)] private float ipd = 0.064f;

        public float IPD
        {
            get => ipd;
            set => ipd = Mathf.Clamp(value, 0.055f, 0.075f);
        }

        private void LateUpdate()
        {
            if (leftEye == null || rightEye == null) return;

            float half = ipd * 0.5f;
            leftEye.transform.localPosition = new Vector3(-half, 0f, 0f);
            rightEye.transform.localPosition = new Vector3(half, 0f, 0f);
        }
    }
}