using System.Collections;
using UnityEngine;
using UnityEngine.UI;

namespace CoreMR.MR
{
    public sealed class PassthroughCamera : MonoBehaviour
    {
        [SerializeField] private bool useRearCamera = true;
        [SerializeField] private int requestedWidth = 1920;
        [SerializeField] private int requestedHeight = 1080;
        [SerializeField] private int requestedFPS = 30;
        [SerializeField] private RawImage outputImage;
        [SerializeField] private Material passthroughMaterial;

        private WebCamTexture cameraTexture;

        public WebCamTexture CameraTexture => cameraTexture;

        private void Start() => StartCamera();

        public void StartCamera()
        {
            if (!Application.HasUserAuthorization(UserAuthorization.WebCam))
            {
                StartCoroutine(RequestCameraPermission());
                return;
            }

            InitializeCamera();
        }

        private IEnumerator RequestCameraPermission()
        {
            yield return Application.RequestUserAuthorization(UserAuthorization.WebCam);

            if (Application.HasUserAuthorization(UserAuthorization.WebCam))
                InitializeCamera();
            else
                Debug.LogError("CORE MR: permissão da câmera negada.");
        }

        private void InitializeCamera()
        {
            WebCamDevice[] devices = WebCamTexture.devices;

            if (devices == null || devices.Length == 0)
            {
                Debug.LogError("CORE MR: nenhuma câmera encontrada.");
                return;
            }

            string deviceName = devices[0].name;

            if (useRearCamera)
            {
                foreach (WebCamDevice device in devices)
                {
                    if (!device.isFrontFacing)
                    {
                        deviceName = device.name;
                        break;
                    }
                }
            }

            cameraTexture = new WebCamTexture(
                deviceName,
                requestedWidth,
                requestedHeight,
                requestedFPS);

            cameraTexture.Play();

            if (outputImage != null)
                outputImage.texture = cameraTexture;

            if (passthroughMaterial != null)
                passthroughMaterial.mainTexture = cameraTexture;
        }

        public void StopCamera()
        {
            if (cameraTexture != null && cameraTexture.isPlaying)
                cameraTexture.Stop();
        }

        private void OnDestroy() => StopCamera();
    }
}