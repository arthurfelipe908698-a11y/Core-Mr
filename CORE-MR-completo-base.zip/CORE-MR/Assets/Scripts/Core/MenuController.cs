using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace CoreMR.Core
{
    public sealed class MenuController : MonoBehaviour
    {
        [SerializeField] private Button startButton;
        [SerializeField] private Button settingsButton;
        [SerializeField] private string mrSceneName = "MRScene";
        [SerializeField] private string settingsSceneName = "SettingsScene";

        private void Awake()
        {
            if (startButton != null)
            {
                startButton.onClick.RemoveAllListeners();
                startButton.onClick.AddListener(StartMR);
            }

            if (settingsButton != null)
            {
                settingsButton.onClick.RemoveAllListeners();
                settingsButton.onClick.AddListener(OpenSettings);
            }
        }

        public void StartMR()
        {
            if (!string.IsNullOrEmpty(mrSceneName))
                SceneManager.LoadScene(mrSceneName);
        }

        public void OpenSettings()
        {
            if (!string.IsNullOrEmpty(settingsSceneName))
                SceneManager.LoadScene(settingsSceneName);
            else
                Debug.LogWarning("CORE MR: SettingsScene não configurada.");
        }

        // Chamados pelo sistema de hand tracking/gesture.
        public void ActivateStartFromHand() => StartMR();
        public void ActivateSettingsFromHand() => OpenSettings();
    }
}