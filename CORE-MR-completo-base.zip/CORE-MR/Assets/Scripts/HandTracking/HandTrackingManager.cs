using System;
using UnityEngine;

namespace CoreMR.HandTracking
{
    [Serializable]
    public struct HandLandmark
    {
        public int index;
        [Range(0f, 1f)] public float x;
        [Range(0f, 1f)] public float y;
        public float z;
        [Range(0f, 1f)] public float confidence;

        public HandLandmark(int index, float x, float y, float z, float confidence)
        {
            this.index = index;
            this.x = x;
            this.y = y;
            this.z = z;
            this.confidence = confidence;
        }
    }

    public sealed class HandTrackingManager : MonoBehaviour
    {
        public const int LandmarkCount = 21;

        [SerializeField, Range(0f, 1f)]
        private float minimumConfidence = 0.60f;

        [SerializeField] private bool trackingEnabled = true;
        [SerializeField] private HandSkeletonRenderer skeletonRenderer;

        private readonly HandLandmark[] landmarks =
            new HandLandmark[LandmarkCount];

        private bool handDetected;

        public bool HandDetected => handDetected;
        public event Action<HandLandmark[]> OnHandUpdated;
        public event Action OnHandLost;

        // Backend de MediaPipe/TFLite/SDK deve chamar este método.
        public void UpdateLandmarks(HandLandmark[] detectedLandmarks)
        {
            if (!trackingEnabled ||
                detectedLandmarks == null ||
                detectedLandmarks.Length < LandmarkCount)
            {
                LoseHand();
                return;
            }

            float confidence = 0f;

            for (int i = 0; i < LandmarkCount; i++)
            {
                landmarks[i] = detectedLandmarks[i];
                confidence += detectedLandmarks[i].confidence;
            }

            confidence /= LandmarkCount;

            if (confidence < minimumConfidence)
            {
                LoseHand();
                return;
            }

            handDetected = true;
            skeletonRenderer?.UpdateSkeleton(landmarks);
            OnHandUpdated?.Invoke(landmarks);
        }

        private void LoseHand()
        {
            if (!handDetected) return;

            handDetected = false;
            skeletonRenderer?.HideSkeleton();
            OnHandLost?.Invoke();
        }

        public HandLandmark GetLandmark(int index)
        {
            if (index < 0 || index >= LandmarkCount)
                throw new ArgumentOutOfRangeException(nameof(index));

            return landmarks[index];
        }

        public void SetTrackingEnabled(bool enabled)
        {
            trackingEnabled = enabled;
            if (!enabled) LoseHand();
        }
    }
}