using UnityEngine;

namespace CoreMR.HandTracking
{
    public sealed class HandSkeletonRenderer : MonoBehaviour
    {
        // 21 landmarks: wrist, thumb, index, middle, ring, pinky.
        private static readonly int[,] Connections =
        {
            {0,1},{1,2},{2,3},{3,4},
            {0,5},{5,6},{6,7},{7,8},
            {5,9},{9,10},{10,11},{11,12},
            {9,13},{13,14},{14,15},{15,16},
            {13,17},{17,18},{18,19},{19,20},
            {0,17}
        };

        [SerializeField] private Transform[] joints = new Transform[21];
        [SerializeField] private LineRenderer[] bones = new LineRenderer[21];
        [SerializeField] private Camera targetCamera;
        [SerializeField] private float depth = 1.0f;

        public void UpdateSkeleton(HandLandmark[] landmarks)
        {
            if (landmarks == null || landmarks.Length < 21 || targetCamera == null)
                return;

            for (int i = 0; i < 21; i++)
            {
                Vector3 viewport = new Vector3(
                    landmarks[i].x,
                    1f - landmarks[i].y,
                    depth);

                Vector3 world = targetCamera.ViewportToWorldPoint(viewport);

                if (joints[i] != null)
                {
                    joints[i].position = world;
                    joints[i].gameObject.SetActive(true);
                }
            }

            for (int i = 0; i < Connections.GetLength(0); i++)
            {
                int a = Connections[i, 0];
                int b = Connections[i, 1];

                if (bones[i] == null) continue;

                bones[i].positionCount = 2;
                bones[i].SetPosition(0, joints[a].position);
                bones[i].SetPosition(1, joints[b].position);
                bones[i].gameObject.SetActive(true);
            }
        }

        public void HideSkeleton()
        {
            foreach (Transform joint in joints)
                if (joint != null) joint.gameObject.SetActive(false);

            foreach (LineRenderer bone in bones)
                if (bone != null) bone.gameObject.SetActive(false);
        }
    }
}