#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;

namespace CoreMR.Editor
{
    public static class AndroidBuild
    {
        private const string OutputFile = "Builds/Android/CORE-MR.apk";

        [MenuItem("CORE MR/Build Android APK")]
        public static void Build() => BuildAndroid();

        public static void BuildAndroid()
        {
            Directory.CreateDirectory("Builds/Android");

            string[] scenes =
            {
                "Assets/Scenes/MainMenu.unity",
                "Assets/Scenes/MRScene.unity"
            };

            BuildPlayerOptions options = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = OutputFile,
                target = BuildTarget.Android,
                options = BuildOptions.None
            };

            BuildReport report = BuildPipeline.BuildPlayer(options);

            if (report.summary.result != BuildResult.Succeeded)
                throw new Exception("CORE MR Android build failed.");

            UnityEngine.Debug.Log(
                $"CORE MR APK generated: {OutputFile}");
        }
    }
}
#endif