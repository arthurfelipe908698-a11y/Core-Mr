Crie MainMenu.unity e MRScene.unity no Unity Editor e adicione-as ao Build Settings.
