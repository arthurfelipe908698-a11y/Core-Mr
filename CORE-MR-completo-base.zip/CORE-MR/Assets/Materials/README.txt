Adicionar aqui NeonBlue.mat e Passthrough.mat.
