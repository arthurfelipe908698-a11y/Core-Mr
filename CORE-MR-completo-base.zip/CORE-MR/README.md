# CORE MR

Projeto-base Unity/Android para MR em VR Box.

## Estrutura principal

- `Assets/Scripts/Core/MenuController.cs`
- `Assets/Scripts/MR/PassthroughCamera.cs`
- `Assets/Scripts/MR/StereoVRBoxRenderer.cs`
- `Assets/Scripts/HandTracking/HandTrackingManager.cs`
- `Assets/Scripts/HandTracking/HandSkeletonRenderer.cs`
- `Assets/Editor/AndroidBuild.cs`
- `.github/workflows/build-apk.yml`

## Cenas esperadas

Crie no Unity:

- `Assets/Scenes/MainMenu.unity`
- `Assets/Scenes/MRScene.unity`

e adicione-as ao Build Settings.

## Menu

Fundo preto, logo CORE MR, botão `iniciar` azul e botão `configurações` branco com contorno azul.

## Hand tracking

`HandTrackingManager` recebe 21 landmarks. O backend de tracking pode ser MediaPipe/TFLite ou outro SDK compatível.

## MR / VR Box

`PassthroughCamera` fornece o feed da câmera traseira. `StereoVRBoxRenderer` separa as câmeras esquerda/direita por IPD. A distorção barrel deve ser calibrada por shader para o modelo de lentes do VR Box.

## CI/CD

Configure no GitHub Actions os secrets:

- `UNITY_EMAIL`
- `UNITY_PASSWORD`
- `UNITY_LICENSE`

O workflow gera `Builds/Android/CORE-MR.apk`.
