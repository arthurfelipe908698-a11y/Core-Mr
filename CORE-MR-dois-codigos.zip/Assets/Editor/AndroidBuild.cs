#if UNITY_EDITOR

using System;
using System.IO;
using System.Collections.Generic;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace CoreMR.Editor
{
    public static class AndroidBuild
    {
        private const string OutputDirectory = "Builds/Android";
        private const string OutputFile = "Builds/Android/CORE-MR.apk";

        public static void Build()
        {
            Debug.Log("===== CORE MR ANDROID BUILD =====");

            Directory.CreateDirectory(OutputDirectory);

            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
            {
                Debug.Log("Mudando plataforma para Android...");

                if (!EditorUserBuildSettings.SwitchActiveBuildTarget(
                    BuildTargetGroup.Android,
                    BuildTarget.Android))
                {
                    throw new Exception("Não foi possível mudar a plataforma para Android.");
                }
            }

            string[] scenes = GetEnabledScenes();

            if (scenes.Length == 0)
            {
                throw new Exception(
                    "Nenhuma cena habilitada no Build Settings."
                );
            }

            PlayerSettings.SetScriptingBackend(
                BuildTargetGroup.Android,
                ScriptingImplementation.IL2CPP
            );

            PlayerSettings.Android.targetArchitectures =
                AndroidArchitecture.ARM64;

            PlayerSettings.productName = "CORE MR";
            PlayerSettings.applicationIdentifier = "com.coremr.app";

            BuildPlayerOptions options = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = OutputFile,
                target = BuildTarget.Android,
                options = BuildOptions.None
            };

            Debug.Log("Iniciando build Android...");

            BuildReport report = BuildPipeline.BuildPlayer(options);

            if (report.summary.result != BuildResult.Succeeded)
            {
                throw new Exception(
                    "Build Android falhou: " +
                    report.summary.result
                );
            }

            if (!File.Exists(OutputFile))
            {
                throw new Exception(
                    "Build terminou sem gerar o APK: " +
                    OutputFile
                );
            }

            Debug.Log("===== CORE MR APK GERADO =====");
            Debug.Log("Arquivo: " + OutputFile);
            Debug.Log(
                "Tamanho: " +
                new FileInfo(OutputFile).Length +
                " bytes"
            );
        }

        private static string[] GetEnabledScenes()
        {
            List<string> scenes = new List<string>();

            foreach (EditorBuildSettingsScene scene
                     in EditorBuildSettings.scenes)
            {
                if (!scene.enabled)
                    continue;

                if (string.IsNullOrEmpty(scene.path))
                    continue;

                if (!File.Exists(scene.path))
                {
                    throw new Exception(
                        "Cena não encontrada: " + scene.path
                    );
                }

                scenes.Add(scene.path);
            }

            return scenes.ToArray();
        }
    }
}

#endif
