package com.coremr.app;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;
import com.google.mediapipe.framework.image.MediaImageBuilder;
import com.google.mediapipe.framework.image.MPImage;
import com.google.mediapipe.tasks.core.BaseOptions;
import com.google.mediapipe.tasks.vision.core.RunningMode;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final int CAMERA_REQUEST = 100;

    private FrameLayout root;
    private PreviewView preview;
    private HandOverlay overlay;
    private HandLandmarker tracker;
    private ExecutorService executor;
    private final Handler handler = new Handler();
    private boolean mrRunning = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        immersive();
        executor = Executors.newSingleThreadExecutor();
        showHome();
    }

    private void showHome() {
        mrRunning = false;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        immersive();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        ImageView background = new ImageView(this);
        background.setImageResource(com.coremr.app.R.drawable.core_mr_menu);
        background.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(background, new FrameLayout.LayoutParams(-1, -1));

        // Transparent hit areas: the supplied artwork remains visually unchanged.
        Button start = hitButton("Iniciar");
        FrameLayout.LayoutParams startLp = new FrameLayout.LayoutParams(-1, -1);
        startLp.gravity = Gravity.TOP | Gravity.START;
        root.addView(start, startLp);
        start.setOnClickListener(v -> beginMR());

        Button settings = hitButton("Configurações");
        FrameLayout.LayoutParams settingsLp = new FrameLayout.LayoutParams(-1, -1);
        settingsLp.gravity = Gravity.TOP | Gravity.START;
        root.addView(settings, settingsLp);
        settings.setOnClickListener(v -> showSettings());

        root.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            int width = right - left;
            int height = bottom - top;
            int buttonWidth = Math.round(width * 0.78f);
            int buttonHeight = Math.round(height * 0.085f);
            int x = (width - buttonWidth) / 2;

            FrameLayout.LayoutParams a = (FrameLayout.LayoutParams) start.getLayoutParams();
            a.width = buttonWidth;
            a.height = buttonHeight;
            a.leftMargin = x;
            a.topMargin = Math.round(height * 0.505f);
            start.setLayoutParams(a);

            FrameLayout.LayoutParams b = (FrameLayout.LayoutParams) settings.getLayoutParams();
            b.width = buttonWidth;
            b.height = buttonHeight;
            b.leftMargin = x;
            b.topMargin = Math.round(height * 0.635f);
            settings.setLayoutParams(b);
        });

        setContentView(root);
    }

    private Button hitButton(String description) {
        Button b = new Button(this);
        b.setText("");
        b.setContentDescription(description);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setAlpha(0.02f);
        return b;
    }

    private void showSettings() {
        new AlertDialog.Builder(this)
                .setTitle("Core MR")
                .setMessage("Modo: Realidade Mista\n\nHand Tracking: MediaPipe\nMãos detectadas: até 2\nCâmera: traseira\n\nO modo VR Box usa a câmera do celular como visão do ambiente e sobrepõe o rastreamento das mãos.")
                .setPositiveButton("OK", null)
                .show();
    }

    private void beginMR() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
            return;
        }
        launchMR();
    }

    private void launchMR() {
        mrRunning = true;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        immersive();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        preview = new PreviewView(this);
        preview.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(preview, new FrameLayout.LayoutParams(-1, -1));

        overlay = new HandOverlay(this);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        TextView label = new TextView(this);
        label.setText("CORE MR  •  REALIDADE MISTA  •  HAND TRACKING");
        label.setTextColor(Color.WHITE);
        label.setTextSize(12);
        label.setGravity(Gravity.CENTER);
        label.setBackgroundColor(0x66000000);
        FrameLayout.LayoutParams labelLp = new FrameLayout.LayoutParams(-2, dp(38));
        labelLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        labelLp.topMargin = dp(12);
        root.addView(label, labelLp);

        Button back = hitButton("Voltar");
        FrameLayout.LayoutParams backLp = new FrameLayout.LayoutParams(dp(100), dp(80));
        backLp.gravity = Gravity.TOP | Gravity.START;
        backLp.leftMargin = dp(12);
        backLp.topMargin = dp(12);
        root.addView(back, backLp);
        back.setOnClickListener(v -> stopMRAndReturnHome());

        setContentView(root);
        setupTracker();
        startCamera();
    }

    private void setupTracker() {
        try {
            BaseOptions base = BaseOptions.builder()
                    .setModelAssetPath("hand_landmarker.task")
                    .build();

            HandLandmarker.HandLandmarkerOptions options = HandLandmarker.HandLandmarkerOptions.builder()
                    .setBaseOptions(base)
                    .setRunningMode(RunningMode.LIVE_STREAM)
                    .setNumHands(2)
                    .setMinHandDetectionConfidence(0.5f)
                    .setMinHandPresenceConfidence(0.5f)
                    .setMinTrackingConfidence(0.5f)
                    .setResultListener((result, timestamp) -> runOnUiThread(() -> {
                        if (overlay != null) overlay.setResult(result);
                    }))
                    .setErrorListener(error -> runOnUiThread(() -> {
                        if (overlay != null) overlay.setError(error.getMessage());
                    }))
                    .build();

            tracker = HandLandmarker.createFromOptions(this, options);
        } catch (Exception e) {
            if (overlay != null) overlay.setError("Hand tracking: " + e.getMessage());
        }
    }

    private void startCamera() {
        ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                ProcessCameraProvider provider = future.get();
                Preview cameraPreview = new Preview.Builder().build();
                cameraPreview.setSurfaceProvider(preview.getSurfaceProvider());

                ImageAnalysis analysis = new ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();
                analysis.setAnalyzer(executor, this::analyze);

                provider.unbindAll();
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, cameraPreview, analysis);
            } catch (Exception e) {
                if (overlay != null) overlay.setError("Câmera: " + e.getMessage());
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void analyze(ImageProxy proxy) {
        try {
            if (tracker != null && proxy.getImage() != null) {
                MPImage image = new MediaImageBuilder(proxy.getImage()).build();
                tracker.detectAsync(image, System.currentTimeMillis());
            }
        } catch (Exception ignored) {
        } finally {
            proxy.close();
        }
    }

    private void stopMRAndReturnHome() {
        if (tracker != null) {
            tracker.close();
            tracker = null;
        }
        showHome();
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_REQUEST && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            launchMR();
        }
    }

    @Override
    public void onBackPressed() {
        if (mrRunning) stopMRAndReturnHome();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (tracker != null) tracker.close();
        if (executor != null) executor.shutdownNow();
        super.onDestroy();
    }
}
