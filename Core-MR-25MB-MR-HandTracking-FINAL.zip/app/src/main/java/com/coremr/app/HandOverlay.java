package com.coremr.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark;
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult;

import java.util.List;

public class HandOverlay extends View {
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint reticle = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private HandLandmarkerResult result;
    private String error = "";

    private static final int[][] CONNECTIONS = {
            {0,1},{1,2},{2,3},{3,4},
            {0,5},{5,6},{6,7},{7,8},
            {0,9},{9,10},{10,11},{11,12},
            {0,13},{13,14},{14,15},{15,16},
            {0,17},{17,18},{18,19},{19,20},
            {5,9},{9,13},{13,17}
    };

    public HandOverlay(Context context) {
        super(context);
        line.setColor(0xFF20DFFF);
        line.setStrokeWidth(6f);
        line.setStyle(Paint.Style.STROKE);
        dot.setColor(Color.WHITE);
        reticle.setColor(0xAA20DFFF);
        reticle.setStrokeWidth(3f);
        reticle.setStyle(Paint.Style.STROKE);
        text.setColor(Color.WHITE);
        text.setTextSize(18f);
    }

    public void setResult(HandLandmarkerResult value) {
        result = value;
        error = "";
        invalidate();
    }

    public void setError(String value) {
        error = value == null ? "" : value;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Small MR reticle in the center of the camera view.
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        canvas.drawCircle(cx, cy, 24f, reticle);
        canvas.drawLine(cx - 40, cy, cx - 10, cy, reticle);
        canvas.drawLine(cx + 10, cy, cx + 40, cy, reticle);
        canvas.drawLine(cx, cy - 40, cx, cy - 10, reticle);
        canvas.drawLine(cx, cy + 10, cx, cy + 40, reticle);

        if (result != null && result.landmarks() != null) {
            for (List<NormalizedLandmark> hand : result.landmarks()) {
                for (int[] connection : CONNECTIONS) {
                    if (connection[1] < hand.size()) {
                        NormalizedLandmark a = hand.get(connection[0]);
                        NormalizedLandmark b = hand.get(connection[1]);
                        canvas.drawLine(
                                a.x() * getWidth(), a.y() * getHeight(),
                                b.x() * getWidth(), b.y() * getHeight(), line);
                    }
                }
                for (NormalizedLandmark point : hand) {
                    canvas.drawCircle(point.x() * getWidth(), point.y() * getHeight(), 8f, dot);
                }
            }
        }

        if (!error.isEmpty()) {
            canvas.drawText(error, 20, 80, text);
        }
    }
}
