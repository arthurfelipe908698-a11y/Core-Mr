package com.coremr.app
// Native hand bridge module.
