// Core MR native module.
