// Core MR JavaScript integration module.
