CORREÇÕES
- Menu agora pode ser fechado e reaberto pelo botão ☰.
- O menu fecha automaticamente ao iniciar MR/VR/Hand Tracking/Tela cheia.
- MR inicia a câmera corretamente.
- Hand Tracking usa WebXR quando o ambiente suporta; no WebView Android sem WebXR, mostra fallback de câmera em vez de fingir que há rastreamento de mãos.
