# Core-Mr APK

Projeto Android que empacota a versão web do Core MR em um APK.

## Recursos
- WebView com JavaScript.
- Câmera com permissão Android.
- Realidade mista baseada em câmera + canvas.
- Controles por toque.
- Estrutura para WebXR e hand tracking quando o ambiente oferecer suporte.

## Gerar APK pelo GitHub
1. Envie esta pasta para seu repositório.
2. Abra a aba Actions.
3. Execute `Build APK`.
4. Baixe o artefato `Core-Mr-debug-apk`.

## Observação
WebXR/Hand Tracking em WebView depende do suporte do dispositivo e do Chromium/WebView instalado. A câmera em MR funciona como uma camada de vídeo atrás dos objetos virtuais.
