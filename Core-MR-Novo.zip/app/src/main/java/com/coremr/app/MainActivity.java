package com.coremr.app;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int CAMERA_REQUEST = 100;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );

        TextView screen = new TextView(this);
        screen.setText("CORE MR");
        screen.setTextSize(32);
        screen.setTextColor(0xFFFFFFFF);
        screen.setGravity(17);
        screen.setBackgroundColor(0xFF000000);
        setContentView(screen);

        if (android.os.Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, CAMERA_REQUEST);
        }
    }
}
