# Core MR

Projeto Android limpo para o Core MR.

Base atual:
- Android APK
- permissão de câmera
- tela inicial simples
- nenhuma função extra adicionada

As funções de realidade mista e rastreamento de mão serão adicionadas nas próximas etapas.
