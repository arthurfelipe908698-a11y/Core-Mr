package com.coremr.app;
import android.app.Activity; import android.os.Bundle; import android.view.View; import android.widget.ImageView;
public class MainActivity extends Activity { public void onCreate(Bundle b){super.onCreate(b); getWindow().getDecorView().setSystemUiVisibility(5894); ImageView v=new ImageView(this); v.setImageResource(R.drawable.core_mr); v.setScaleType(ImageView.ScaleType.CENTER_CROP); setContentView(v);} }
