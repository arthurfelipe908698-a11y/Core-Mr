# VR-BOX-MR
Projeto inicial para VR Box, WebXR, câmera de realidade mista e controles por toque.

## Como usar no celular
1. Crie um repositório no GitHub.
2. Extraia o ZIP.
3. Envie os arquivos para o repositório.
4. Ative GitHub Pages.
5. Abra o endereço HTTPS do Pages no navegador.

## Importante
WebXR e acesso à câmera dependem do navegador, HTTPS e do hardware. Hand Tracking real também depende do suporte WebXR/hand-tracking do dispositivo.
